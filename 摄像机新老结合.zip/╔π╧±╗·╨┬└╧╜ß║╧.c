
/******************************************************************************
*********************************************/
#define NEW_IMAGE_VAR
#include <vcrt.h>
#include <vclib.h>
#include <macros.h>
#include <sysvar.h>
#include <flib.h>

#include <math.h>
/******************************************************************************
*********************************************/
//#define   _COM_TO_PC_      //ʹ��ͨѶ

#define  CAPT_EXP            		200 //�ع�ʱ��
#define  CAPT_GAIN_INIT      	0x100//ͼ������

//#define  CAPT_EXP            600 //�ع�ʱ��
//#define  CAPT_GAIN_INIT      0xa0//ͼ������

#define  IniNrOfScreens      		4
#define  ReleaseAllocation  		-1
#define  NextScreen           		0
#define  GAP_DIS               		2

#define NOInitBkg              		15
#define RLC_MAXLNG      		0x50000
#define NOPage 			6
#define NORLC 			4
//------------------------------
#define  _USE_SMALL_WINDOW_ 

//------------------------------
#define RECEIVE_BYTES      3  
#define RECEIVE_BYTES_TR      2
#define SERVER_PORT     2002  /* waiting at port 2002 for any connection */
#define MEMORY           500000  /* memory to store one image */

//------------------------------
#define  BigWinColumns       400
#define  BigWinRows            300

#define  SmallWinColumns       30	
#define  SmallWinRows            30

#define  MiddleWinColumns      70	
#define  MiddleWinRows           70

#define   BALL_SIZE                   10
#define   BALL_TH                       7000
//------------------------------
#define  dx_win_max     50

//------------------------------
#define ER_SIZE        1  //��֡����
#define DL_SIZE        3  //��֡��ʴ


#define LF 					15
#define DBKG_TH_MIN         	15  //�����ֵ
#define AREA_DBKG_MAX         250  //��������
#define AREA_DBKG_MIN         	10  //����С���
#define DELTA_DBKG_MAX         	50  //����״��󷽲�

//#define MAXOBJ  800
#define MAXOBJ  10
#define threshold_sub  35
#define threshold_orign 60

/***************************************************************************************************************************/
double w,h,squ,ratePi,cenX,cenY;
int blobTestFlag = 0;
int xLabel=0,yLabel=0;
/************************************************************************************/

/******************************************************************************
*********************************************/

//ȫ�־�̬����

static int *Screen,*ScrAdr;
static int Cur_index,Old_index;

static int NrOfScreens=0, *TrackNr, disp, calc, capt;


static int CacheSrcPage[NOPage],CachePage[NOPage];
static int TempPage;     //��Ų�֡ͼ��
static int Dcur_bin_Page;//��Ų�֡��ֵͼ��
static int EptBckPage;   //��ſձ���ͼ��
static int MaskPage;     //��ſձ�����֡ͼ��
static int EptBck_th_Page;   //��ſձ���ͼ��
static int Dcur_Page;   //���С���ڿղ��ֵͼ��

image template_img;

static U16 *rlc_cache[NORLC];
static U16 *rlc_source,*rlc_stage1,*rlc_stage2,*rlc_temp;

int x_lable_his[2],y_lable_his[2];
static unsigned char his_far_pos = 0;
static unsigned char his_near_pos = 1;

static int img_gain = CAPT_GAIN_INIT; 

  
static int X0,Y0,X_last,Y_last;
static int life_for_template;
//void calculation   (image* area);
//��������
int  ScreenBuffer  (int mode,image* area);
//-------------------------------------------

void mem_init(void);
//-------------------------------------------

int my_dilate(U16* rlc_source,U16* rlc_out,int size);
int my_erode(U16* rlc_source,U16* rlc_out,int size);
//-------------------------------------------

int   Brightness(image area);
void InitBkgImg(int* pBKG_ST, int* pBKG_TH_ST);
void RefreashBKG(image bkg_img, image bkg_th_img, image cur_img,int* pBKG_ST, int* pBKG_TH_ST);
//-------------------------------------------
int   Find_ppq(image cur_img,image old_img,image bkg_img,image bkg_th_img, int* px, int* py,int win_flag);
int   Find_ppq_close(image cur_small_img, image bkg_small_img, image bkg_smallth_img, int* px, int* py);

void upload_lable_his(int x_lable,int y_lable);
void mark(int a,int b,char *out);
int ImgCopy(image src, image dis);
void TCP_trans(void);

int Find_ball_old(image cur_img, image old_img,int* px, int* py);
/******************************************************************************
*********************************************/

#define NumOfPT 13
float ptx[NumOfPT];
float pty[NumOfPT];
unsigned char poll[NumOfPT][NumOfPT];
unsigned char pollOut[NumOfPT][2];
void GetCenter(float *pt, U32 count, int *cen)
{//*pt,input vecetor
 // count: number of the vecetor
 //output:cen, the center of data
  float sum=0;//�ܺ�
  float aver=0;//��ֵ
  float theshold =0;//��ֵ
  float maxDis;
  float temp;
  unsigned char temp2;
  U16 i,j,num;
  
  //FL_accu_U16P_U32P(count, pt, &sum);
  sum = pt[0];
  for (i=1; i< count; i++)
  	sum = sum + pt[i];
  
  *cen = (int)(sum * 10.0 / count);
  aver = sum / count;
  //Ѱ����Զ��
  maxDis = fabs(pt[0] - aver);
  for (i=1;i<count;i++)
  {
  	temp = fabs(pt[i]-aver);
  	if (temp>maxDis)
  	maxDis = temp;
  }
  theshold = maxDis * 2.0 / 3.0;//��ֵ
/*//ֱ���޳��ִ����  
  sum = 0;
  num =0;
  for (i=0;i<count;i++)
  {
  	temp = fabs(pt[i]-aver);
  	if (temp<=theshold)
  	{
  	  sum = sum + pt[i];
  	  num++;
  	}
  }
  if(num>0)
  	*cen = (int)(sum * 10.0 / num);
//  printf(" nc:%d",num); */

//ͶƱ
	memset(poll,0,sizeof(unsigned char)*NumOfPT);
	for (i=0;i<count; i++)
	{
		for(j=i;j<count; j++)
		{
			if (fabs(pt[i]-pt[j]) < theshold)
			{
				poll[i][j] = 1;
				poll[j][i] = 1;
			}			
		}
	}
//ͳ��	
	for(i=0;j<count;i++)
	{
		pollOut[i][0]=0;
		pollOut[i][1]=i;
		for(j=0;j<count;j++)
		{
			pollOut[i][0] += poll[i][j];
		}
	}
//����
	for(i=0;i<count-1; i++)
	{
		for(j=i+1;j<count;j++)
		{
			if(pollOut[j][0]>pollOut[i][0])
			{
				temp2 = pollOut[j][0];
				pollOut[j][0] = pollOut[i][0];
				pollOut[i][0] = temp2;
				temp2 = pollOut[j][1];
				pollOut[j][1] = pollOut[i][1];
				pollOut[i][1] = temp2;
			}
		}
	}
//ȡǰnum�����ݽ��м���
	num = 9;//NumOfPT = 13ʱ
	sum = 0;
	for (i=0; i < num; i++)
	{
		sum += pt[pollOut[i][1]];
	}
  	*cen = (int)(sum * 10.0 / num);
	
}
int GSPWithFilter(image * square,int *X_ball,int *Y_ball)
{
	int Dx[NumOfPT]={-4,0,0,4, 0,  -1,0,1, 0,  -2,0,2, 0};
	int Dy[NumOfPT]={ 0,4,0,0,-4,   0,1,0,-1,   0,2,0,-2};
	int k,i;
	U32 No_Y=0,No_X=0;
	int GR=1,GL=1,GM=1,GN=1,lenL=0,lenR=0,lenM=0,lenN=0;
	float current_X,current_Y;
	int pitch,thres_GSP=threshold_orign;
	float Xlabel,Ylabel;
	
        pitch=DispGetPitch;
	current_X=(*X_ball);
	current_Y=(*Y_ball);
	
	for(k=0;k<NumOfPT;k++)
	{    
		Xlabel=current_X+Dx[k];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
		Ylabel=current_Y+Dy[k];	
		GR=1;
		GL=1;
		GM=1;
		GN=1;
		lenL=0;
		lenR=0;
		lenM=0;
		lenN=0;
		for(i=0;i<30;i++)
		{			
			if(GL&&(*(unsigned char *)(square->st+(int)Ylabel*pitch+(int)(Xlabel-i))>thres_GSP))	    lenL=lenL+1;
			else GL=0;
			if(GR&&(*(unsigned char *)(square->st+(int)Ylabel*pitch+(int)(Xlabel+i))>thres_GSP))	    lenR=lenR+1;
			else GR=0;
			if(GM&&(*(unsigned char *)(square->st+(int)(Ylabel-i)*pitch+(int)Xlabel)>thres_GSP))		lenM=lenM+1;
			else GM=0;
			if(GN&&(*(unsigned char *)(square->st+(int)(Ylabel+i)*pitch+(int)Xlabel)>thres_GSP))		lenN=lenN+1;
			else GN=0; 
		}
		
		if((lenL+lenR<30)&&(lenL+lenR>3))
		{
			ptx[No_X]=Xlabel+(lenR - lenL)/2.0;
			No_X++;
		}
		if ((lenN+lenM<30)&&(lenN+lenM>3))                   
		{
			pty[No_Y]=Ylabel+(lenN - lenM)/2.0;
			No_Y++;
		}		
	}
//	printf(" nx%d, ny%d",No_X,No_Y);
	if (No_X >0)
	{
		GetCenter(ptx,No_X,X_ball);
		//*X_ball = (*X_ball)*10;
	}
	else
	{
//		printf(" nc:0");
		*X_ball = (*X_ball)*10;
	}
	if (No_Y >0)
	{
		GetCenter(pty,No_Y,Y_ball);
		//*Y_ball = (*Y_ball)*10;
	}
	else
	{
//		printf(" nc:0");
		*Y_ball = (*Y_ball)*10;
	}
	
	return 1; 
}


int find_objects (image *a, ftr *f, int maxobjects, int th, int display)
{
       long maxlng= 0x5000;
		
	U16 *rl1, *rl2, *slc;
	int  objects;
	
	/* allocate DRAM Memory */
	rl1 = rlcmalloc(maxlng);
	if (rl1 == NULL) {pstr("DRAM Memory overrun\n"); return(-1);}
	
	/* create RLC */
	rl2=rlcmk(a, th, rl1, maxlng);
	if (rl2 == NULL) {pstr("RLC overrun\n"); rlcfree(rl1); return(-1);}
	
	// you can use some filter (dilate, erode) 
	if (1) // 1=with filter 0=no filter
    	{
		slc=erode2(rl1,rl2);
		
    	}
	else
    	{
		slc=rl2;
		rl2=rl1;
    	}
	
	/* object labelling */
	if(sgmt(rl2,slc)==NULL) {pstr("object number overrun\n"); rlcfree(rl1); return(-1);}
	
	/* feature extraction */
	objects=rl_ftr2(rl2, f, maxobjects);
	
	/* display RLC */
	if (display) rlcout(a,rl1,0,255);
	
	/* free allocation */
	rlcfree(rl1);  
	
	return(objects);
}

int blobtest(image *area,int x, int y, int dx, int dy,int * x0,int * y0,unsigned char  flagRoi)
{       
//��һ�����趨thresholdֵ
//�ڶ���������width,height,rate,area�Ȳ���
	
	int i=0, nobj=0,display=1;
	ftr f[MAXOBJ];
	int width,height;
	float rate;    
	
	nobj=find_objects(area,f,MAXOBJ,threshold_sub ,display);  //ROI searching
				
	for(i=0;i<nobj;i++)
	{
		width=(f[i].x_max-f[i].x_min);
		height=(f[i].y_max-f[i].y_min);
		if(width>height)
			rate=width/2.0;
		else
			rate=height/2.0;
		rate=(float)f[i].area/(rate*rate);
		
	    //�Զ�����2013-4-10
		if((f[i].color==-1)&&
			(width<=20&&width>=3)&&
			(height<=20&&height>=3)&&(fabs(width-height)<=20)&&
			f[i].area>=10&&f[i].area<200
			&&rate>0.5&&rate<4.5)  
		{
			xLabel=f[i].x_center+x;
			yLabel=f[i].y_center+y;
						       
			
			w = width;
			h = height;
			squ = f[i].area;
			ratePi = rate;
			*x0 = xLabel;
			*y0 = yLabel;
			
			return 1;
		}
	} 
   
   return 0;      
}





void main(void)
{
  int   TimeInit=0,Clock_Time,Clock_Time_last,TimeS,TimeS_last,TimeGap;
  int   Clock_idle_init,Clock_idle,Clock_LastRef,IdleTime, RefTime;
  int   timeRcv_Last=0;
  int   timeRcv_Cur,time_Send;
  int    i;
  char  key=0; 
  image area,cur_img,old_img,bkg_img,bkg_th_img;
  image cur_middlewin_img,old_middlewin_img,bkg_middlewin_img,bkg_middlewin_th_img;
  
  
  int x_lable,y_lable;
  int* pBKG_ST, * pBKG_TH_ST;

  int win_flag;

  
  int x_ofs,y_ofs;

  int Ref_Count = 0 ;


    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  unsigned char      *linebuffer;
  int 				sendbuf[5];
  sockaddr_in    	laddr, raddr;
  unsigned       		sock, listensock;
  unsigned       		error;
  uint_16        		rlen;
  int result;
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  char  receivedata[RECEIVE_BYTES]; 
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  uint_32 opt_value = RECEIVE_BYTES;

  init_licence("T2237AE5748"); 
  // ====================================================================================
  // ====================================================================================
  pBKG_ST 	= (int*)sysmalloc(120000,2);
  if(pBKG_ST == NULL){print("sysmalloc wrong \n");}
  pBKG_TH_ST = (int*)sysmalloc(120000,2);
  if(pBKG_TH_ST == NULL){print("sysmalloc wrong \n");}
  mem_init();

  life_for_template = 0;
  ScrSetLogPage (Dcur_Page);
  ImageAssign(&template_img, ScrByteAddr(2*SmallWinColumns,0), BALL_SIZE,BALL_SIZE,ScrGetPitch);
 				
  // -----------------------------------------
  //��ʼ����ǰ�����¿յı���ͼƬ,����������


  print("\n����ձ���:�������̨,���������ʼ����\n"); 
  getchar();


  InitBkgImg(pBKG_ST, pBKG_TH_ST );
  TimeS = 0;
  TimeInit = getvar(MSEC);

  //====================================================================================
  OvlClearAll;
  print("Press any key to start\n"); 
  print("Press 'q' to quit\n"); 
  print("Press 'c' to clear screen\n");  
  getchar();
  
  //==========================================
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#ifdef  _COM_TO_PC_
   /* server services port */
   laddr.sin_family      = AF_INET;
   laddr.sin_port         = SERVER_PORT;   /* server listen at port SERVER_PORT (2002) */
   laddr.sin_addr.s_addr = INADDR_ANY;    /* every IP addr can connect to the camera */
   /* use TCP/IP protocoll and search for a free port */
   sock = socket_stream();
   if (sock == VCRT_HANDLE_ERROR) 
   {
     print("\nCreate stream socket failed");
     return;
   } 
   
   setsockopt(sock,SOL_TCP,OPT_RBSIZE,&opt_value,sizeof(uint_32 ));
   
   /* connection between free port and selected SERVER_PORT. Now SERVER_PORT is free again for new connections. */
   error = bind(sock, &laddr, sizeof(laddr));
   if (error != VCRT_OK) 
   {
     print("\nStream bind failed - 0x%x", error);
     return;
   }
   /* activate sock for TCP/IP connections */
   error = listen(sock, 0);
   if (error != VCRT_OK) 
   {
     print("\nListen failed - 0x%x", error);
     return;
   }
   listensock = sock;
   print("\n\nFast Ethernet port %d\n",laddr.sin_port);
  

  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  while(1)
  {
	  sock = VCRT_selectall(0);
	  if (sock == listensock)
      	  {
	        /* Connection requested; accept it */
	        rlen = sizeof(raddr);

	        /* accept connection */
	        print("\nwait for accept");
	        sock = accept(listensock, &raddr, &rlen);
	        if (sock == VCRT_HANDLE_ERROR)
	        {
	          print("\nAccept failed, error 0x%x",VCRT_geterror(listensock));
	          continue;
	        }
	        else
	        {
	          print("\naccept ready");
	        }

	        print("\nConnection from %d.%d.%d.%d, port %d",
	           (raddr.sin_addr.s_addr >> 24) & 0xFF,
	           (raddr.sin_addr.s_addr >> 16) & 0xFF,
	           (raddr.sin_addr.s_addr >>  8) & 0xFF,
	            raddr.sin_addr.s_addr        & 0xFF,
	            raddr.sin_port);
#endif //_COM_TO_PC_

		  //========================================		  
		  win_flag = 0;
		  while(1)
		  {
		  	if (kbhit())
			{
				key = rs232rcv();
			       if(key == 'q')break;
			       if(key == 'c')OvlClearAll;
			}  

			sendbuf[0] = 0;  sendbuf[1] = 0;
			sendbuf[2] = 0;  sendbuf[3] = 0;
			sendbuf[4] = 0;
#ifdef  _COM_TO_PC_
			recv(sock, (char *)receivedata, RECEIVE_BYTES, 0); 
			if(receivedata[0]=='T'&&receivedata[1]=='C')
			{
				TimeS = 0;
				TimeInit = getvar(MSEC);
				Clock_Time = TimeInit;
				sendbuf[0] = 2;
				sendbuf[3] = Clock_Time;
				linebuffer = (unsigned char*)sendbuf;
				result=send(sock, (char *)linebuffer, 20, 0);
				print("TC\n");
			        if(result==VCRT_ERROR) 
			        {
			          	print("\nSend TIMECONFIG_ERR",VCRT_geterror(sock));
			        }
			        continue;
			}
			//timeRcv_Cur = (int)(receivedata[0])*1000 + (int)receivedata[1];
			
#endif //_COM_TO_PC_
			    TimeGap = getvar(MSEC);
			    ScreenBuffer(NextScreen,&area);

			    Clock_Time = getvar(MSEC) - TimeInit;
			    if(Clock_Time<0)Clock_Time += 1000;
			    if(Clock_Time_last > Clock_Time)TimeS++;
			    if(TimeS==3600)TimeS=0; //ÿ3600s��ʱ������һ��
			    Clock_Time_last = Clock_Time;	
			    TimeS_last         = TimeS;
				//print("gap = %d\n",Clock_Time);
		//	Clock_Time++;
		//	if(Clock_Time>1000){Clock_Time =0;TimeS++;}
		//	if(TimeS==3600)TimeS=0; //ÿ3600s��ʱ������һ��
				
			
			life_for_template--;
			if(life_for_template < 0) life_for_template = 0;
			
		
			ImageAssign(&cur_img, 		(long)Screen[Cur_index]	,   	BigWinColumns, BigWinRows, ScrGetPitch);
			ImageAssign(&old_img, 		(long)Screen[Old_index]	,   	BigWinColumns, BigWinRows, ScrGetPitch);
			ImageAssign(&bkg_img, 		(long)EptBckPage          	,   	BigWinColumns, BigWinRows, ScrGetPitch);	
			ImageAssign(&bkg_th_img, 	(long)EptBck_th_Page		,	BigWinColumns, BigWinRows, ScrGetPitch);	

			
 /*			if( Ref_Count > 1000   )
			{
				RefreashBKG(bkg_img,bkg_th_img,cur_img,pBKG_ST,pBKG_TH_ST);
				Ref_Count = 0 ;
				print("REF\n");
			}
*/
			//=======================================
			if(win_flag == 1)
			{
				
				//Ԥ���µĴ���λ��
			   /* 	x_ofs = x_lable_his[his_near_pos] - x_lable_his[his_far_pos];
			    	if(x_ofs > dx_win_max)x_ofs = dx_win_max; 
			    	else if( x_ofs < -dx_win_max)x_ofs = - dx_win_max;
			    	y_ofs = y_lable_his[his_near_pos] - y_lable_his[his_far_pos];
			    	if(y_ofs > dx_win_max)y_ofs = dx_win_max; 
			    	else if( y_ofs < -dx_win_max)y_ofs = - dx_win_max;
			    */	
			       X0 = x_lable  - MiddleWinColumns/2;  	
				Y0 = y_lable  - MiddleWinRows/2;
				if(X0<0)X0=0;
				else if(X0 + MiddleWinColumns >= BigWinColumns)X0=BigWinColumns-1-MiddleWinColumns;
				if(Y0<0)Y0=0;
				else if(Y0 + MiddleWinRows >= BigWinRows)Y0 = BigWinRows-1-MiddleWinRows;
					
				//=============================================================== 		
				ImageAssign(&cur_middlewin_img, (cur_img.st + X0 + Y0 * ScrGetPitch) , MiddleWinColumns, MiddleWinRows, ScrGetPitch);
				ImageAssign(&old_middlewin_img, (old_img.st + X0 + Y0 * ScrGetPitch) , MiddleWinColumns, MiddleWinRows, ScrGetPitch);
				ImageAssign(&bkg_middlewin_img, (bkg_img.st + X0 + Y0 * ScrGetPitch), MiddleWinColumns, MiddleWinRows, ScrGetPitch);				
				ImageAssign(&bkg_middlewin_th_img, (bkg_th_img.st + X0 + Y0 * ScrGetPitch), MiddleWinColumns, MiddleWinRows, ScrGetPitch);				

				
				if(Find_ppq(cur_middlewin_img, old_middlewin_img, bkg_middlewin_img, bkg_middlewin_th_img, &x_lable, &y_lable, win_flag)
				||Find_ball_old(cur_middlewin_img, old_middlewin_img, &x_lable, &y_lable))
				{
					win_flag = 1;
					x_lable += X0;
					y_lable += Y0;
					mark(x_lable,y_lable,"*");
					upload_lable_his(x_lable,y_lable);

					TimeGap = getvar(MSEC) -TimeGap;
					if( TimeGap < 0 ){ TimeGap+= 1000 ;}
				//	print("TG = %d \n",TimeGap);
					time_Send = TimeGap + timeRcv_Last;
					timeRcv_Last = timeRcv_Cur;
					
					sendbuf[0] = 1;
					sendbuf[1] = x_lable*10;
					sendbuf[2] = y_lable*10;
					sendbuf[3] = TimeS_last;
					sendbuf[4] = Clock_Time_last;
					//sendbuf[3] = (char)(time_Send/1000) ;
					//sendbuf[4] = (char)(time_Send%1000);
				//	print("%d %d\n",sendbuf[3],sendbuf[4]);

					Ref_Count = 0 ;
				}
				else
					win_flag = 0;	

			}
			if(win_flag == 0)
			{
				//print("bw\n");
				X0 = 0; Y0 = 0;
				if(Find_ppq(cur_img, old_img, bkg_img, bkg_th_img, &x_lable, &y_lable, win_flag))
				{
					//mark(x_lable,y_lable,"S");
					win_flag = 1;
					x_lable_his[his_near_pos] =  x_lable;
					y_lable_his[his_near_pos] =  y_lable;
					x_lable_his[his_far_pos ] =  x_lable;
					y_lable_his[his_far_pos ] =  y_lable;

					Ref_Count = 0 ;
				}
				else
					win_flag = 0;	
			}
			Ref_Count ++ ;
			linebuffer = (unsigned char*)sendbuf;
			result=send(sock, (char *)linebuffer, 20, 0);	
		  }
#ifdef  _COM_TO_PC_
		 shutdown(sock, FLAG_CLOSE_TX);
	   	 print("\nshutdown\n");
	  }
	  print("\nidle\n");
  	  shutdown(listensock, FLAG_CLOSE_TX);
	  break;
  }
#endif
   //TCP_trans();   
  print("Programm Exit.\n");	
  
  /* release screen allocation (mode<0) */
  ScreenBuffer(ReleaseAllocation,&area);
  for(i=0;i<NOPage;i++)DRAMPgFree(CacheSrcPage[i]);
  for(i=0;i<NORLC ;i++)vcfree(rlc_cache[i]);
  sysfree(pBKG_ST);
  sysfree(pBKG_TH_ST);
  
  vmode(vmLive);
}

/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/







/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/

int ScreenBuffer (int mode,image* area)
  {
  int i;
  
  image Iniarea;

  /* only possible in vmOvlStill mode */
  vmode(vmOvlStill);

  /* screen allocation mode */
  if (mode>0)
    {
    if (NrOfScreens != 0) return(-5);
    if (mode<3)  return(-4);
    if (mode>20) return(-4);
    
    NrOfScreens=mode;

    ScrAdr=(int *)sysmalloc(NrOfScreens,2); 
    if((int)ScrAdr==0) 
      {
      return(-1);
      }

    Screen=(int *)sysmalloc(NrOfScreens,2); 
    if((int)Screen==0) 
      {
      sysfree((void *)ScrAdr);
      return(-1);
      }

    TrackNr=(int *)sysmalloc(NrOfScreens,2); 
    if((int)TrackNr==0) 
      {
      sysfree((void *)Screen);
      sysfree((void *)ScrAdr);
      return(-1);
      }

    Screen[0]=ScrGetCaptPage;
    for (i=1; i<NrOfScreens; i++)  
      {
      ScrAdr[i]=(int)DRAMDisplayMalloc(); 
      if (ScrAdr[i]==0)
        {
        for (i-=1; i>0; i--)  
          {
          DRAMPgFree(ScrAdr[i]);
          }
        sysfree((void *)TrackNr);
        sysfree((void *)Screen);
        sysfree((void *)ScrAdr);
        return(-1);
        }

      /* Image display addresses have to be in alignments of 1024 */ 
      Screen[i]=(ScrAdr[i]&0xFFFFFC00) + 1024;

     
      ImageAssign(&Iniarea, (long)Screen[i], DispGetColumns, DispGetRows, ScrGetPitch);  
      set(&Iniarea,0);
      }

    for (i=0; i<NrOfScreens-2; i++)  
      {
      TrackNr[i]=capture_request(CAPT_EXP,img_gain,(int *)Screen[i],0);
      if(TrackNr[i]==0) return(-2);
      }
      
    
    	capt =  0;
    	calc =   1;
    	disp =   2;
	 //||capt||calc||disp||... 
	 
    }
    
  /* change screen for display, calculation and acquisition */
  if (mode==0)
    {
    if (NrOfScreens==0) return(-3);

    /* waiting for complete image */
    while(TrackNr[calc] > getvar(IMGREADY));

    TrackNr[capt]=capture_request(CAPT_EXP,img_gain,(int *)Screen[capt],0);
    if(TrackNr[capt]==0) return(-2);

    ScrSetDispPage(Screen[disp]);
   // ScrSetLogPage (Screen[calc]);
    ImageAssign(area, (long)Screen[calc], DispGetColumns, DispGetRows, ScrGetPitch);

	Cur_index = calc;
    Old_index = Cur_index + GAP_DIS;
    if(Old_index>=NrOfScreens)Old_index -= NrOfScreens;

    capt -- ;
    calc  --;
    disp  --;
    if (capt<0) capt=NrOfScreens-1;
    if (calc<0) calc=NrOfScreens-1;
    if (disp<0) disp=NrOfScreens-1;
    
    //||capt||calc||disp||... 
    //||calc ||disp|| ... ||capt 
    
        //assert(GAP_DIS < NrOfScreens-1 );

    
    
    
    }


  /* release screen allocation mode */
  if (mode<0)
    {
    if (NrOfScreens==0) return(-3);
 
    ScrSetPhysPage(Screen[0]);

    for (i=NrOfScreens-1; i>0; i--)  
      {
      DRAMPgFree(ScrAdr[i]);
      }

    NrOfScreens=0;

    sysfree((void *)TrackNr);
    sysfree((void *)Screen);
    sysfree((void *)ScrAdr);
    
    ScrSetLogPage(Screen[capt]);
    vmode(vmLive);
    }
    
    
  return(0);
  }


/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/







/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/
int my_dilate(U16* rlc_source,U16* rlc_out,int size)
{
	U16 * rlc_1,*rlc_2,*rlc_3;
	int i;
	if( size <= 1 )
	{
		dilate(rlc_source,rlc_out);
		return 1;
	}	
	else
	{
		rlc_2 = rlc_source;
		rlc_3 = rlc_temp;
		for(i=0;i<size-2;i++)
		{
			rlc_1 = rlc_2;
			rlc_2 = rlc_3;
			rlc_3 = dilate(rlc_1,rlc_2);
		}
		dilate(rlc_2,rlc_out);
		return 1;
	}
	
}

int my_erode(U16* rlc_source,U16* rlc_out,int size)
{
	U16 * rlc_1,*rlc_2,*rlc_3;
	int i;
	if( size <= 1 )
	{
		erode(rlc_source,rlc_out);
		return 1;
	}	
	else
	{
		rlc_2 = rlc_source;
		rlc_3 = rlc_temp;
		for(i=0;i<size-2;i++)
		{
			rlc_1 = rlc_2;
			rlc_2 = rlc_3;
			rlc_3 = erode(rlc_1,rlc_2);
		}
		erode(rlc_2,rlc_out);
		return 1;
	}
	
}
/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/







/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/
int Brightness(image area)
{
	int i,j,sum=0;
	unsigned char * pixel;
	int temp;
	for(j=0;j<area.dy ;j+=1)
    {
            pixel=area.st + j*area.pitch;

            for(i=0;i<area.dx;i+=1) 
            {
            	temp = (int)(*pixel);
				sum += temp;
				pixel+=1;
            }
     }
     return sum;
}

void InitBkgImg(int* pBKG_ST, int* pBKG_TH_ST)
{
	int i;
	int temp;
	int m,n;
	image area,cur_img,bkg_img,bkg_th_img;
	unsigned char *pixel_cur,*pixel_bkg,*pixel_th_bkg;
	int* pixel_int_bkg,*pixel_int_th_bkg;

	//memset(pBKG_ST,0,4*120000);
	//memset(pBKG_TH_ST,0,4*120000);
	for(i = 0;i<120000;i++)
	{
		*(pBKG_ST+i) = 0;
		*(pBKG_TH_ST+i) = 0;
	}
	ImageAssign(&bkg_img,      (long)EptBckPage,        BigWinColumns, BigWinRows, ScrGetPitch); 
	ImageAssign(&bkg_th_img, (long)EptBck_th_Page, BigWinColumns, BigWinRows, ScrGetPitch); 
	
	
	for(i=0;i<NOInitBkg;i++)
	{
		ScreenBuffer(NextScreen,&area);
		ImageAssign(&cur_img, (long)Screen[Cur_index], BigWinColumns, BigWinRows, ScrGetPitch); 

		pixel_int_bkg 	= 	pBKG_ST;
		pixel_int_th_bkg 	= 	pBKG_TH_ST;
	
		for(m=0;m<cur_img.dy;m++)
		{
			pixel_cur = cur_img.st + m*cur_img.pitch;
			for(n=0;n<cur_img.dx;n++)
			{
				temp = (int)(*pixel_cur);
				(*pixel_int_bkg)      += temp;
				(*pixel_int_th_bkg) += temp*temp;
				pixel_cur++;
				pixel_int_bkg++;
				pixel_int_th_bkg++;
			}
		} 
	}
//-----------------------------
	pixel_int_bkg 	= 	pBKG_ST;
	pixel_int_th_bkg 	= 	pBKG_TH_ST;
	for(m=0;m<bkg_img.dy;m++)
	{
		pixel_bkg      = bkg_img.st + m*bkg_img.pitch;
		pixel_th_bkg = bkg_th_img.st + m*bkg_th_img.pitch;
		for(n=0;n<bkg_img.dx;n++)
		{
			temp = (*pixel_int_bkg);
			//*pixel_bkg      = (unsigned char )(temp/10);
			*pixel_int_bkg = (temp/NOInitBkg);
			*pixel_int_th_bkg = 3*sqrt(((*pixel_int_th_bkg) - temp*temp/NOInitBkg)/NOInitBkg);
			*pixel_bkg      = (unsigned char )(*pixel_int_bkg);
			*pixel_th_bkg = (unsigned char )(*pixel_int_th_bkg);
			
		/*	*pixel_bkg      = (unsigned char )(temp/NOInitBkg);
			*pixel_th_bkg = (unsigned char )3*sqrt(((*pixel_int_th_bkg) - temp*temp/NOInitBkg)/NOInitBkg);
			*/
			if(*pixel_th_bkg<DBKG_TH_MIN)*pixel_th_bkg = DBKG_TH_MIN;
			pixel_int_bkg++;
			pixel_int_th_bkg++;
			pixel_bkg++;
			pixel_th_bkg++;
		}
	} 
	

	
  	
  
  //("\n���ȵ�������,����Ϊ %d \n",BrightnessVal);
}

void mem_init(void)
{
  int i,result;
  image area;
  image exp_Tab_img;
  	
  for(i=0;i<NORLC;i++)
  {
  	rlc_cache[i] =(U16*)vcmalloc(RLC_MAXLNG);
  	if (rlc_cache[i] ==NULL ) {pstr("RLC Memory overrun\n"); return;}
  }
  
  rlc_source = rlc_cache[0];
  rlc_stage1 = rlc_cache[1];
  rlc_stage2 = rlc_cache[2];
  rlc_temp   = rlc_cache[3];
  //----------------------------------------------- 
  for(i=0;i<NOPage;i++)
  {
  	CacheSrcPage[i] = (int)DRAMDisplayMalloc();   //��֡ͼ��
  	CachePage[i]    = (CacheSrcPage[i]&0xFFFFFC00) + 1024;
  }
    
  TempPage  = CachePage[0];
  Dcur_bin_Page = CachePage[1];
  EptBckPage= CachePage[2];
  MaskPage  = CachePage[3];
  EptBck_th_Page = CachePage[4];
  Dcur_Page = CachePage[5];

  
  
  
  //-----------------------------------------------
  //��ʼ����Ϊ������������ڴ�
  result = ScreenBuffer(IniNrOfScreens,&area);
  if (result < 0) {print("Screen Allocation Error %d\n",result); return;}
}


/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/







/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/
void TCP_trans(void)
{
   unsigned char *linebuffer, *plinebuf, *pixel;
   char  receivedata[RECEIVE_BYTES_TR]; 
   int  i, j, x, y, dx, dy, incrx, incry, result, ms, count, ScreenIndex=0;
   long sec;
   sockaddr_in    laddr, raddr;
   unsigned       sock, listensock;
   unsigned       error;
   uint_16        rlen;


   /* transfer the image from the physical page */
  // ScrSetLogPage((int)ScrGetPhysPage);


   /* temporarily work around */
 //  tpict();
  // setvar(DISP_ACTIVE,0);


   /* allocate memory for image raw data */
   linebuffer=(unsigned char *)sysmalloc(MEMORY,3);
   if((int)linebuffer==0) print("not enough memory\n");


   /* server services port */
   laddr.sin_family      = AF_INET;
   laddr.sin_port        = 2004;   /* server listen at port SERVER_PORT (2002
) */
   laddr.sin_addr.s_addr = INADDR_ANY;    /* every IP addr can connect to the 
camera */


   /* use TCP/IP protocoll and search for a free port */
   sock = socket_stream();

   if (sock == VCRT_HANDLE_ERROR) 
     {
     print("\nCreate stream socket failed");
     return;
     } 

   /* connection between free port and selected SERVER_PORT. Now SERVER_PORT 
is free again for new connections. */
   error = bind(sock, &laddr, sizeof(laddr));

   if (error != VCRT_OK) 
     {
     print("\nStream bind failed - 0x%x", error);
     return;
     }

   /* activate sock for TCP/IP connections */
   error = listen(sock, 0);

   if (error != VCRT_OK) 
     {
     print("\nListen failed - 0x%x", error);
     return;
     }

   listensock = sock;

   print("\n\nFast Ethernet port %d\n",laddr.sin_port);

   for (;;) {

      /* Are there connections at any port? The number 0 means: Wait until connection */
      sock = VCRT_selectall(0);

      /* Is there one who wants to connect to port SERVER_PORT */
      if (sock == listensock)
      {
        /* Connection requested; accept it */
        rlen = sizeof(raddr);

        /* accept connection */
        print("\nwait for accept");
        sock = accept(listensock, &raddr, &rlen);
        if (sock == VCRT_HANDLE_ERROR)
        {
          print("\nAccept failed, error 0x%x",VCRT_geterror(listensock));
          continue;
        }
        else
        {
          print("\naccept ready");
        }

        print("\nConnection from %d.%d.%d.%d, port %d",
           (raddr.sin_addr.s_addr >> 24) & 0xFF,
           (raddr.sin_addr.s_addr >> 16) & 0xFF,
           (raddr.sin_addr.s_addr >>  8) & 0xFF,
            raddr.sin_addr.s_addr        & 0xFF,
            raddr.sin_port);


        do
        {
          print("\n\nWaiting for image size");
		
		 x=0;
		 y=0;
         dx=600;
         dy=480;
         incrx = 1;
         incry = 1;
         
         count = recv(sock, (char *)receivedata, RECEIVE_BYTES_TR, 0); 
          ScreenIndex=0;

          if(count == VCRT_ERROR)
            print("\nVCRT_ERROR 0x%x",VCRT_geterror(sock));
          else
            if(count < RECEIVE_BYTES_TR)
               print("\nonly %d bytes read",count);
          else /* no errors*/
          { 
          	ScreenIndex=receivedata[0];
          }

        /* dx=0 : quit program */
        if (ScreenIndex != 'e')
        {
         // tpict();
         //ImageAssign(&trans_img, (long)Screen[ScreenIndex], DispGetColumns, DispGetRows, ScrGetPitch);
		  print("\nTrains NO.%d image",(int)ScreenIndex);
          if(ScreenIndex == 0)ScrSetLogPage(Dcur_bin_Page);
	   if(ScreenIndex == 1)ScrSetLogPage(Dcur_Page);	
	

          count=0;

          for(j=0;j<dy;j+=incry)
          {
            pixel=(unsigned char *)ScrByteAddr(x,y+j);

            for(i=0;i<dx;i+=incrx) 
            {
              *plinebuf++ = *pixel;
               pixel+=incrx;
               count++;
            }
          }

          sec = getvar(SEC);
          ms  = getvar(MSEC);
           
          result=send(sock, (char *)linebuffer, count, 0);
          if(result==VCRT_ERROR) 
          {
            print("\nSend VCRT_ERROR=%lx",VCRT_geterror(sock));
          }
          else
          {
            if(result!=count)    
            print("\nSend error wrong length=%d result=%d",count,result);
          }

          sec = getvar(SEC)-sec;
          ms  = getvar(MSEC)-ms;
            
          ms = 1000*(int)sec + ms;
          print(" \n trans t=%dms",ms);
        }
        }
       // while(ScreenIndex!='e');
		while(ScreenIndex == 0);
		
        shutdown(sock, FLAG_CLOSE_TX);
        };

     break;

   } /* Endfor */
   shutdown(listensock, FLAG_CLOSE_TX);

   sysfree(linebuffer);


   /* activate image display */
 //  setvar(DISP_ACTIVE,1);

vmode(vmLive);

} 

/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/







/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/
void mark(int a,int b,char *out)
{
	image OvlArea;
	OvlSetLogPage((int)OvlGetPhysPage);
	ImageAssign(&OvlArea,OvlBitAddr(a,b),5,5,OvlGetPitch);
	set_overlay_bit(2,255,0,0);
	set(&OvlArea,4);	
	chprint1(out,&OvlArea,1,1,4);
	set_ovlmask(255);
}

int ImgCopy(image src, image dis)
{
	unsigned char * pixel_src,* pixel_dis;
	int i,j;
	int dx,dy,pitch;
	dx = src.dx;
	dy = src.dy;
	pitch = src.pitch;

	if(dx == dis.dx && dy == dis.dy && pitch == dis.pitch)
	{
		for(j=0;j<dy ;j+=1)
		{
		      	pixel_src = src.st + j*pitch;
			pixel_dis  = dis.st +  j*pitch;	
			for(i=0;i<dx;i+=1) 
		       {
		       		*pixel_dis = *pixel_src;
		       		pixel_src++;
			   	pixel_dis++;
			}
		}
		return 1;
	}
	else
	{
		return 0;
	}
}
	
/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/

void RefreashBKG(image bkg_img, image bkg_th_img, image cur_img, int* pBKG_ST, int* pBKG_TH_ST)
{
	int i,j;
	unsigned char * pixel_cur,* pixel_bkg,* pixel_th_bkg;
	int * pbkg_int,*pbkg_th_int;
	int temp;

	pbkg_int 	= pBKG_ST;
	pbkg_th_int 	= pBKG_TH_ST;
	for(j=0;j<bkg_img.dy ;j+=1)
	{
	      	pixel_bkg = bkg_img.st + j*bkg_img.pitch;
		pixel_cur  = cur_img.st +  j*cur_img.pitch;	
		pixel_th_bkg = bkg_th_img.st + j*bkg_th_img.pitch;
		for(i=0;i<bkg_img.dx;i+=1) 
	       {
	       		temp = (int)((*pixel_cur)-(*pixel_bkg));
	       		*pbkg_int 	= ((*pbkg_int)*LF 	   + (int)(*pixel_cur))/(LF+1);
			*pbkg_th_int 	= ((*pbkg_th_int)*LF  + 3*temp*temp)/(LF+1);
	
			*pixel_bkg = (unsigned char)(*pbkg_int);
			*pixel_th_bkg = (unsigned char)(*pbkg_th_int);
			if(*pixel_th_bkg<DBKG_TH_MIN)*pixel_th_bkg = DBKG_TH_MIN;
			
	       		pixel_bkg++;
			pixel_cur++;
			pbkg_int++;
			pbkg_th_int++;	
		}
	}
}



/***************************************************************************************************************************/
/***************************************************************************************************************************/
void upload_lable_his(int x_lable,int y_lable)
{
	his_far_pos = ((his_far_pos ==1)?0:1);
	his_near_pos =((his_near_pos==1)?0:1);
	x_lable_his[his_near_pos] = x_lable;
	y_lable_his[his_near_pos] = y_lable;
}
/***************************************************************************************************************************/
/***************************************************************************************************************************/


/******************************************************************************
*********************************************/
/******************************************************************************
*********************************************/

int   Find_ppq(image cur_img,image old_img,image bkg_img,image bkg_th_img, int* px, int* py, int win_flag)
{
	int i,j,X0_sw,Y0_sw;
	U16* slc;
	unsigned char *pixel,*p_for_pixel,*pixel_for_bkgTh;
	unsigned char  tempUp,tempDn;
		
	image dcur_img,dcur_bin_img;
	image cur_small_img,bkg_smallth_img,bkg_small_img,dcur_smallBin_img;
	
	image exp_Tab_img,template_win_img;
	
	int count_for_try = 0;
	
	//----------------------------
	ImageAssign(&dcur_bin_img, (long)Dcur_bin_Page, cur_img.dx,cur_img.dy,cur_img.pitch);		   
	ImageAssign(&dcur_img, (long)TempPage, cur_img.dx,cur_img.dy,cur_img.pitch);


	
	//----------------------------
	sub2(&cur_img,&old_img,&dcur_img);
	
	if(!win_flag)//�ڴ󴰿��У�ֻ�ҿ�����ĵ�
	{
		subx2(&dcur_img,&bkg_th_img,&dcur_bin_img,100); 
		subx2(&dcur_bin_img,&bkg_th_img,&dcur_bin_img,0);
		slc=rlcmk(&dcur_bin_img, 100, rlc_source, RLC_MAXLNG);
    		if (slc == NULL ) {pstr("RLC overrun\n"); vcfree((int*)rlc_source);return 0; }
	}
	else//��С�����У����Ǹ���
	{	
    		subx2(&dcur_img,&bkg_th_img,&dcur_bin_img,100); 
		subx2(&dcur_bin_img,&bkg_th_img,&dcur_bin_img,0);
		slc=rlcmk(&dcur_bin_img, 100, rlc_source, RLC_MAXLNG);
    		if (slc == NULL ) {pstr("RLC overrun\n"); vcfree((int*)rlc_source);return 0; }
	}

	
	//----------------------------    

	my_erode(rlc_source,rlc_stage2,ER_SIZE);
    	my_dilate(rlc_stage2,rlc_source,DL_SIZE);
	rlcout(&dcur_bin_img,rlc_source,0,255);
	

	for(j=0;j<dcur_bin_img.dy ;j+=1)
	{
	      	pixel=dcur_bin_img.st + j*dcur_bin_img.pitch;
		for(i=0;i<dcur_bin_img.dx;i+=1) 
	       {
	       		if(*pixel == 255 && count_for_try < 5)
			{
				count_for_try++;
				X0_sw = i  - SmallWinColumns/3;
				Y0_sw = j  - SmallWinRows/3;
				if(X0_sw<0)X0_sw=0;
				else if( (X0_sw + SmallWinColumns) >= BigWinColumns-1 )X0_sw = BigWinColumns - 1 - SmallWinColumns;
				if(Y0_sw<0)Y0_sw=0;
				else if( (Y0_sw + SmallWinRows     ) >= BigWinRows-1      )Y0_sw = BigWinRows - 1 - SmallWinRows;
		
				ImageAssign(& cur_small_img,    (long)cur_img.st +X0_sw+Y0_sw*cur_img.pitch     , SmallWinColumns     ,SmallWinRows     , cur_img.pitch     );
				ImageAssign(& bkg_small_img,    (long)bkg_img.st +X0_sw+Y0_sw*bkg_img.pitch     , SmallWinColumns     ,SmallWinRows     , bkg_img.pitch     );
				ImageAssign(& bkg_smallth_img, (long)bkg_th_img.st +X0_sw+Y0_sw*bkg_th_img.pitch     , SmallWinColumns     ,SmallWinRows     , bkg_th_img.pitch     );
				
				if( Find_ppq_close(cur_small_img,bkg_small_img,bkg_smallth_img,px,py) ) 
				{
					*px += X0_sw;
					*py += Y0_sw;

					X_last = *px;
					Y_last = *py;
					return 1;
				}
				else
				{
					ImageAssign(& dcur_smallBin_img, (long)dcur_bin_img.st +X0_sw+Y0_sw*dcur_bin_img.pitch     , SmallWinColumns     ,SmallWinRows     , dcur_bin_img.pitch     );
					set(&dcur_smallBin_img,0);
					//mark(X0_sw+X0,Y0_sw+Y0,"X");
				}
			}
			pixel++;
	        }
	}

	count_for_try = 0;
	sub2(&cur_img,&bkg_img,&dcur_img);
	subx2(&dcur_img,&bkg_th_img,&dcur_bin_img,100); 
	slc=rlcmk(&dcur_bin_img, 100, rlc_stage1, RLC_MAXLNG);
/*	my_dilate(rlc_source,rlc_stage1,6);
	rlc_inv(rlc_stage1);
	my_dilate(rlc_stage1,rlc_stage2,6);
	rlcand(rlc_source,rlc_stage2,rlc_stage1);
*/	my_dilate(rlc_stage1,rlc_source,2);
	rlcout(&dcur_bin_img,rlc_source,0,255);
	//------------------------------------------
	if(win_flag)
	for(j=0;j<dcur_bin_img.dy ;j+=1)
	{
	      	pixel=dcur_bin_img.st + j*dcur_bin_img.pitch;
		for(i=0;i<dcur_bin_img.dx;i+=1) 
	       {
	       		if(*pixel == 255 && count_for_try < 5)
			{
				count_for_try++;
				X0_sw = i  - SmallWinColumns/3;
				Y0_sw = j  - SmallWinRows/3;
				if(X0_sw<0)X0_sw=0;
				else if( (X0_sw + SmallWinColumns) >= BigWinColumns-1 )X0_sw = BigWinColumns - 1 - SmallWinColumns;
				if(Y0_sw<0)Y0_sw=0;
				else if( (Y0_sw + SmallWinRows     ) >= BigWinRows-1      )Y0_sw = BigWinRows - 1 - SmallWinRows;
		
				ImageAssign(& cur_small_img,    (long)cur_img.st +X0_sw+Y0_sw*cur_img.pitch     , SmallWinColumns     ,SmallWinRows     , cur_img.pitch     );
				ImageAssign(& bkg_small_img,    (long)bkg_img.st +X0_sw+Y0_sw*bkg_img.pitch     , SmallWinColumns     ,SmallWinRows     , bkg_img.pitch     );
				ImageAssign(& bkg_smallth_img, (long)bkg_th_img.st +X0_sw+Y0_sw*bkg_th_img.pitch     , SmallWinColumns     ,SmallWinRows     , bkg_th_img.pitch     );
				
				if( Find_ppq_close(cur_small_img,bkg_small_img,bkg_smallth_img,px,py) ) 
				{
					*px += X0_sw;
					*py += Y0_sw;

					X_last = *px;
					Y_last = *py;
					//print("MAKE IT\n");
					return 1;
				}
				else
				{
					ImageAssign(& dcur_smallBin_img, (long)dcur_bin_img.st +X0_sw+Y0_sw*dcur_bin_img.pitch     , SmallWinColumns     ,SmallWinRows     , dcur_bin_img.pitch     );
					set(&dcur_smallBin_img,0);
					//mark(X0_sw+X0,Y0_sw+Y0,"X");
				}
			}
			pixel++;
	        }
	}
	//-------------------------------------------
		
    	if (slc == NULL ) {pstr("RLC overrun\n"); vcfree((int*)rlc_source);return 0; }
	
	return 0;
}

int   Find_ppq_close(image cur_small_img, image bkg_small_img, image bkg_smallth_img, int* px, int* py)
{
	image dbkg_small_img,dbkg_smallBin_img,P_pixel_img,P_ball_img,cur_template_img;
	int i,j;
	int tempUp,tempDn,temp;
	int sumx,sumy,sumxx,sumyy,count,deltx,delty;
	int P_ball, P_ball_max,ball_count,p_ball_count;
	unsigned char *pixel,*p_for_pixel,*pixel_for_bkgTh;
	
	U16* slc;
	//----------------------------
	ImageAssign(&dbkg_small_img,      (long)MaskPage, SmallWinColumns    ,SmallWinRows     , cur_small_img.pitch     );					
	ImageAssign(&dbkg_smallBin_img ,(long)Dcur_Page, SmallWinColumns    ,SmallWinRows     , cur_small_img.pitch     );					
		
	//----------------------------
	sub2(&cur_small_img, &bkg_small_img,    &dbkg_small_img);
	
	subx2(&dbkg_small_img,&bkg_smallth_img,&dbkg_smallBin_img,100); 
	slc=rlcmk(&dbkg_smallBin_img, 100, rlc_source, RLC_MAXLNG);
	rlcout(&dbkg_smallBin_img,rlc_source,0,255);

	//----------------------------
 	sumx = 0;    sumy = 0;
	sumxx = 0;  sumyy = 0;
	count = 0;
	for(j=0;j<dbkg_smallBin_img.dy ;j+=1)
	{
		pixel=dbkg_smallBin_img.st + j*dbkg_smallBin_img.pitch;
		for(i=0;i<dbkg_smallBin_img.dx;i+=1) 
	       {
	        	if(*pixel == 255)
			{
				sumx += i;
				sumy += j;
				count +=1;
				sumxx += i*i;
				sumyy += j*j;
			}
			pixel++;
	        }
	}
			
	sumx = sumx/count;
	sumy = sumy/count;
	sumxx = sumxx/count;
	sumyy = sumyy/count;	
	deltx = sumxx - sumx*sumx;
	delty = sumyy - sumy*sumy;
	
//	print("delt = %d\n",deltx); 
//	print("count = %d\n",count );
	
	if( count > AREA_DBKG_MAX
	|| count < AREA_DBKG_MIN
	|| deltx  > DELTA_DBKG_MAX
	|| delty  > DELTA_DBKG_MAX)
	{return 0;} 
	else
	{
		*px = sumx;*py = sumy; 
		return 1;
	}
	
}

int Find_ball_old(image cur_middlewin_img, image old_middlewin_img,int* px, int* py)
{
       int return_blobtest;
       image dcur_img;
       ImageAssign(&dcur_img, (long)TempPage, cur_middlewin_img.dx,cur_middlewin_img.dy,cur_middlewin_img.pitch);
	sub2(&cur_middlewin_img,&old_middlewin_img,&dcur_img);
	   
	return_blobtest = blobtest(&dcur_img,0,0,dcur_img.dx,dcur_img.dy,px,py,0);
	if(return_blobtest!=0)        
	{
				//���ص�ǰͼ��Ѱ��
		GSPWithFilter(&cur_middlewin_img, px, py);
		*px = (*px)/10;
		*py = (*py)/10;
		return 1;
	}
	return 0;
}



